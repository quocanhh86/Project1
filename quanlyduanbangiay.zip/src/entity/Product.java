package entity;

import annotation.Column;
import annotation.Id;
import annotation.Table;
import java.util.Objects;

/**
 *
 * @author Admin
 */
@Table(name = "SANPHAM")
public class Product {
    @Id
    @Column(name = "SANPHAMID")
    private Integer id;
    @Column(name = "TENSANPHAM")
    private String name;
    @Column(name = "DANHMUCID")
    private Integer categoryId;
    @Column(name ="TRANGTHAI")
    private String status;
    @Column(name = "KIEUDANGID")
    private Integer modelId;
    @Column(name = "HINHANH")
    private byte[] image;

    public Product() {
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public Integer getCategoryId() {
        return categoryId;
    }

    public void setCategoryId(Integer categoryId) {
        this.categoryId = categoryId;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public Integer getModelId() {
        return modelId;
    }

    public void setModelId(Integer modelId) {
        this.modelId = modelId;
    }

    public byte[] getImage() {
        return image;
    }

    public void setImage(byte[] image) {
        this.image = image;
    }

    @Override
    public int hashCode() {
        int hash = 7;
        hash = 23 * hash + Objects.hashCode(this.id);
        hash = 23 * hash + Objects.hashCode(this.name);
        return hash;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        final Product other = (Product) obj;
        if (!Objects.equals(this.name, other.name)) {
            return false;
        }
        return Objects.equals(this.id, other.id);
    }
    
    
}
