package Repository.impl;

import Repository.StaffRepo;
import entity.Staff;

public class StaffRepoImpl extends AbstractBaseRepo<Staff, Integer> implements StaffRepo {
}
