package Repository.impl;

import Model.OrderViewModel;
import Repository.OrderRepo;
import Utils.DatabaseUtils;
import entity.Order;

import java.sql.PreparedStatement;
import java.util.List;

public class OrderRepoImpl extends AbstractBaseRepo<Order, Integer> implements OrderRepo {
    @Override
    public List<OrderViewModel> findAllPendingOrder() throws Exception {
        PreparedStatement pstm = super.connection.prepareStatement(statusPendingQuery);
        DatabaseUtils.printQueryLog(statusPendingQuery);
        return OrderViewModel.mapToList(pstm.executeQuery());
    }
}
