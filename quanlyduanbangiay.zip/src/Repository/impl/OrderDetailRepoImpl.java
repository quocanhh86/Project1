package Repository.impl;

import Repository.OrderDetailRepo;
import entity.OrderDetail;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

public class OrderDetailRepoImpl extends AbstractBaseRepo<OrderDetail, Integer> implements OrderDetailRepo {

    @Override
    public List<OrderDetail> findAllByCondition(Integer productId, Integer orderId) throws Exception {
        List<OrderDetail> entities = new ArrayList<>();
        PreparedStatement preparedStatement = connection.prepareStatement(queryFindAllByCondition);
        preparedStatement.setInt(1, productId);
        preparedStatement.setInt(2, orderId);
        ResultSet resultSet = preparedStatement.executeQuery();
        while (resultSet.next()) {
            OrderDetail orderDetail = new OrderDetail();
            orderDetail.setId(resultSet.getInt("HOADONCHITIETID"));
            orderDetail.setOrderId(resultSet.getInt("HOADONID"));
            orderDetail.setProductDetailId(resultSet.getInt("CHITIETSANPHAMID"));
            orderDetail.setQuantity(resultSet.getInt("SOLUONG"));
            orderDetail.setPrice(resultSet.getDouble("DONGIA"));
            entities.add(orderDetail);
        }
        return entities;
    }

    @Override
    public void deleteByOrderId(Integer orderId) throws Exception {
        PreparedStatement preparedStatement = connection.prepareStatement(queryDeleteByOrderId);
        preparedStatement.setInt(1, orderId);
        preparedStatement.executeUpdate();
    }
}
