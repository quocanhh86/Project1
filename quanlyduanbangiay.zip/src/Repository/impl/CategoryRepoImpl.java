package Repository.impl;

import Repository.CategoryRepo;
import entity.Category;

public class CategoryRepoImpl extends AbstractBaseRepo<Category, Integer> implements CategoryRepo {
}
