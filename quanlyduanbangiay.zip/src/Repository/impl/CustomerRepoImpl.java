package Repository.impl;

import Repository.CustomerRepo;
import entity.Customer;

public class CustomerRepoImpl extends AbstractBaseRepo<Customer, Integer> implements CustomerRepo {
}
