package Repository;

import entity.Customer;

public interface CustomerRepo extends BaseRepo<Customer, Integer> {
}
