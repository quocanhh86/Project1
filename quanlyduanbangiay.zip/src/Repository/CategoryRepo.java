package Repository;

import entity.Category;

public interface CategoryRepo extends BaseRepo<Category, Integer> {
}
