package Repository;

import entity.OrderDetail;

import java.util.List;

public interface OrderDetailRepo extends BaseRepo<OrderDetail, Integer>{
    String queryFindAllByCondition = "SELECT * FROM HOADONCHITIET WHERE CHITIETSANPHAMID = ? AND HOADONID = ?";
    String queryDeleteByOrderId = "DELETE FROM HOADONCHITIET WHERE HOADONID = ?";
    List<OrderDetail> findAllByCondition(Integer productDetailId, Integer orderId) throws Exception;

    void deleteByOrderId(Integer orderId) throws Exception;
}
