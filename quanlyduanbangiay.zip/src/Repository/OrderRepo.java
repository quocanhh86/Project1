package Repository;

import Model.OrderViewModel;
import entity.Order;

import java.util.List;

public interface OrderRepo extends BaseRepo<Order, Integer>{
    String statusPendingQuery = "SELECT HD.HOADONID ID,HD.MAHOADON MAHD,NV.TENNHANVIEN TENNHANVIEN,KH.TENKHACHHANG TENKHACHHANG,HD.NGAYTAO NGAYTAO,HD.TONGTIEN TONGTIEN,HD.TRANGTHAI TRANGTHAI FROM HOADON HD\n" +
        "LEFT JOIN NHANVIEN NV ON NV.NHANVIENID = HD.NHANVIENID\n" +
        "LEFT JOIN KHACHHANG KH ON KH.KHACHHANGID = HD.KHACHHANGID\n" +
        "WHERE HD.TRANGTHAI LIKE N'Chưa thanh toán'";

    List<OrderViewModel> findAllPendingOrder() throws Exception;
}
