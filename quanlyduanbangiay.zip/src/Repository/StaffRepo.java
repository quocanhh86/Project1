package Repository;

import entity.Staff;

public interface StaffRepo extends BaseRepo<Staff,Integer>{
}
